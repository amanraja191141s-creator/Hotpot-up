# Build verification — SA Calculator v99.05 CI repair

- App version: `1.99.19-v99.05`
- Android versionCode: `1099134`
- Service-worker cache: `sa-calculator-v99-05-viewport-tools-navigation-v9905`
- Root cause of reported Actions failure: workflow required `REFERENCE-VIDEO-UI-AUDIT-v99.05.md`, but the release archive did not contain that exact file; only the historical v99.04 audit existed.
- Added the correctly versioned v99.05 audit and included `tests/viewport-tools-navigation-v9905.test.mjs` in the workflow's required-file verification list.
- Strengthened `tests/ci-cache-workflow.test.mjs` to assert both release artifacts exist and are required by CI.
- `node --check assets/js/app.js`: passed.
- `npm run build:web`: passed.
- `npm run test:release`: 55/55 passed.
- Standalone Android YAML and `.github/workflows/main.yml`: byte-identical.
- Required release files: all present and non-empty.
- Exactly one root application `package.json` in the ZIP; ZIP integrity verified.
- Physical Android device test and a fresh GitHub Actions run: pending; not claimed as passed.
