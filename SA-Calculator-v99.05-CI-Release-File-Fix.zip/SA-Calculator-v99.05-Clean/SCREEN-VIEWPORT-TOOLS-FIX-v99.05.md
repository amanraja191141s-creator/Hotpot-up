# SA Calculator v99.05 — Android screen viewport and Tools navigation fix

## Screenshot diagnosis
- The HTML head contained a bare text node, `Base application styles.`. HTML parsing moved it into the body.
- The body uses a flex layout. That unexpected text node became an anonymous flex item before `#app-container`, pushing the application shell to the right.
- The visible symptoms match the supplied Android screenshot: left-side text fragment, clipped scientific expression, clipped right keypad column, and a partially visible app viewport.
- The primary bottom navigation markup contained Calculator, History and Settings only. Existing JavaScript already handled a `tools` destination and CSS expected a four-column navigation, but the actual Tools button was missing.

## Changes
- Removed the stray head text node.
- Hardened the Android WebView shell: centered, bounded app container; zero minimum widths; clipped horizontal overflow at the shell; full-width viewport and screens.
- Added a real Tools destination to the bottom navigation, wired to the existing `switchScreen('tools')` handler.
- Preserved all 12 requested tool cards and their existing calculation systems.
- Added automated regression tests for the malformed head content, Tools navigation, and viewport constraints.
- Bumped release identity to `1.99.19-v99.05`, Android versionCode `1099134`, and service-worker cache namespace to force fresh assets after update.

## Verification
- `node --check assets/js/app.js`: passed.
- `npm run build:web`: passed.
- `npm run test:release`: 54/54 passed.
- HTML parse: no duplicate IDs; exactly 12 tool launchers; exactly 4 bottom-navigation destinations.
- Root and `www/` copies of index, JS and CSS are byte-identical.
- GitHub Actions YAML parses successfully and standalone YAML is byte-identical to `.github/workflows/main.yml`.
- ZIP integrity checked after packaging.

## Device validation limitation
No live Android device session was available in this run. The source-level root cause and navigation omission are corrected and regression-tested, but a fresh install/update on the target phone is still needed to confirm the exact rendered pixels and touch behavior. After installing, fully close the old app once and reopen it so the new service-worker cache is activated.
