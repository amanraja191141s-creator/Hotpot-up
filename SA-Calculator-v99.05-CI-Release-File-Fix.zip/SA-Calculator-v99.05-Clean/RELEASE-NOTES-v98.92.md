# SA Calculator v98.92 — Release Notes

- Positioned `GST Rate(%)` in the upper marked row beside the percent icon.
- Kept `Add rate`, `5%`, and `18%` together on the lower row.
- Removed duplicate GST amount/rate placeholder rendering.
- Synchronized Same State / Different State result-row visibility before input validation.
- Added accessible `aria-hidden` state for the hidden GST breakdown rows.
- Synchronized the 5% / 18% active preset state when users type or delete a rate manually.
- Kept custom caret placement, formatted amount input, horizontal caret scrolling, and shared keypad behaviour.
- Added five v98.92 regression checks; total automated suite: 148 passing tests.
