# SA Calculator v99.04

- Restored the 12 requested tool workspaces and their working input/output controls.
- Restricted tool launcher/search/category/favorites registry to exactly those 12 tools.
- Removed the seven unrequested tool screens and their launcher routes.
- Re-enabled only the retained Currency Converter, Unit Converter, and percentage-mode initialization required by the retained tools.
- Preserved shared numeric tool keypad, main/scientific calculator, history, settings, themes, and localization.
- Updated release identity to `1.99.17-v99.04` and Android versionCode `1099133`.
