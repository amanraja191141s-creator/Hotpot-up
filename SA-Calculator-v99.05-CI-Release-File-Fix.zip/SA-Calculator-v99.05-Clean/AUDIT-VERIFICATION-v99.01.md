# SA Calculator v99.01 — Source and release audit

## Scope
- Source archive: `SA-Calculator-v99.01-Tool-Cards-Code-Purged.zip`
- Android workflow: `sa-calculator-v99.01-android.yml`
- Release identity: `1.99.15-v99.01`
- Android versionCode: `1099130`

## Verified
- ZIP integrity checked successfully before extraction.
- JavaScript syntax checks passed for app, localization, theme bootstrap, server, service worker, and Android build scripts.
- Release regression suite: **177 passed, 0 failed**.
- `npm run build:web` completed successfully.
- Source and generated `www/` copies match byte-for-byte for HTML, service worker, JS and CSS checked.
- All 10 local HTML `src`/`href` asset references resolved.
- Release version, manifest, Capacitor webDir, service-worker cache namespace and test entry points are aligned with the supplied workflow.
- Card-removal regression tests passed: legacy tool-card selectors/classes are absent from the active HTML/CSS/JS contracts; semantic tool groups and input/result behavior checks remain present.
- The supplied workflow parses as YAML and is installed as `.github/workflows/main.yml`.

## Packaging correction
The uploaded ZIP stored the project under a wrapper directory (`v999_work/`). This release ZIP places the project files at the archive root so it can be extracted directly as a repository/project folder and the workflow can find `package.json` without manual folder navigation.

## Not claimed
An Android APK was **not** built in this local audit environment. The workflow installs npm/Android dependencies and performs the Android SDK/Gradle build on GitHub Actions. No physical-device interaction or runtime performance test was performed here, so absolute “lag-free/bug-free” behavior cannot be guaranteed from static and automated tests alone.

## Release notes
No calculator logic or UI behavior was changed during this packaging pass because the supplied source passed its release regression suite. The purpose of this output is to deliver a correctly rooted, reproducibly verifiable source package and its matching Android workflow without introducing unverified behavioral changes.
