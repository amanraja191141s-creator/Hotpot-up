# SA Calculator v98.76 — Reference Video Exact Tool Rebuild

- Rebuilt Currency, GST, Loan, Discount, Unit, Age and BMI tool surfaces from the supplied reference recordings.
- Removed non-reference refresh/heading/Calculate UI from Currency/GST/Discount/Unit flows where the shared keypad action is the reference action.
- Added exact horizontal Unit category chips and Unit List picker behavior.
- Added Current and Voltage unit categories and video-matched defaults for Weight, Time, Volume, Data, Current and Voltage.
- Currency defaults to USD → INR with blank source input and compact paired cards.
- Tool screens use the light reference surface independent of calculator home theme.
- Shared keypad geometry and swap action are aligned to the supplied 720×1560 recordings.
- Age Calculator keeps its in-screen Calculate action and does not auto-open the numeric dock.
- BMI/Loan/GST/Discount result surfaces are committed only after the shared equals action.
- Service-worker cache namespace bumped to force clean Android/WebView asset refresh.
