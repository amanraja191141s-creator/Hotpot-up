# SA Calculator v98.96 — Video-driven card content geometry audit

## Source evidence
Two Android screen recordings dated 2026-11-24 show overlapping field labels/placeholders/entered values and clipped card content across GST, Loan, Salary, Saving, Tip, SIP, Currency, Unit Converter and BMI screens.

## Root cause found in v98.95 source
The final CSS layer applied `height`, `min-height` and `max-height` of 64px with `overflow-y:auto` to a broad list of unrelated card families. Earlier, tool-specific CSS defines taller compound fields (GST/finance/BMI 145px and currency 122px) with icon, label and input rows. The late blanket `!important` rule overrode those layouts, compressing multi-row content into 64px and turning fields into nested scroll containers. The v98.95 regression test asserted the cap existed but did not test that the inner field composition remained visible.

## Correction
- Removed the blanket 64px height/min-height/max-height and inner vertical-scroll overrides.
- Restored established per-tool geometry from the existing screen-specific CSS: GST/finance/BMI fields retain their own 145px rules; currency retains 122px; other tools keep their individually authored sizes.
- Kept a shared 430px maximum width, fluid narrow-screen width, border-box sizing and min-width safeguards only.
- Preserved the existing custom caret, numeric keypad, calculations, result lifecycle, theme tokens and tool-specific control layouts.
- Bumped app version to `1.99.10-v98.96`, Android versionCode to `1099116`, and changed the service-worker cache namespace to force stale v98.95 styles to be discarded.

## Regression coverage
A new test rejects a global 64px height cap, checks known multi-row tool geometry, checks width-only shared constraints, checks narrow-screen overflow safeguards, and checks source/www CSS parity.

## Validation boundary
Automated tests and source checks can verify the regression fix structurally. Physical Android screenshots, touch/scroll behavior, frame pacing and APK installation still require a real device / GitHub Actions build.
