# Finance calculator UI micro-audit — v98.75

## Screenshot measurements translated to logical units
Reference image: 709 × 1536 px. Approximate density conversion: 2 physical pixels per logical pixel.

| Element | Reference estimate | v98.75 target |
|---|---:|---:|
| Left/right page inset | 24 px / 2 = 12 dp | 12 px |
| Input card width | 660 px / 2 = 330 dp | 100% of content width |
| Input card height | 176 px / 2 = 88 dp | 88 px min-height |
| Compact card height | compact | 82 px min-height |
| Card border | about 4 physical px | 2 px |
| Card radius | about 44 physical px | 22 px |
| Inner padding | about 24 physical px | 12 px |
| Icon tile | about 100 × 100 physical px | 50 × 50 px |
| Icon-to-content gap | about 24 physical px | 12 px |
| Field label | about 30 physical px | 15 px |
| Value/placeholder | about 44 physical px | 22 px |
| GST choice chips | about 50 physical px high | 25 px |

## Per-screen mapping

### GST
- First card: Original Amount; banknote icon tile; label above placeholder.
- Below first card: right-aligned With GST / Without GST compact pills.
- Second card: GST Rate(%) field at left and 5% / 18% quick rates at right.
- Below second card: right-aligned Same State / Different State compact pills.
- Result card hidden before equals; after equals show GST amount, CGST/SGST or IGST, and total amount.
- Keypad remains docked while entering; equals calculates and dismisses it.

### Saving
- Exactly three visible cards in order: Saving Amount, Interest Rate(%), Saving Period.
- Monthly contribution, compounding frequency and tax inputs remain hidden for compatibility with the existing savings engine; monthly contribution defaults to zero and tax defaults to zero.
- Saving Period's years suffix is presentation-only; the stored field remains numeric.
- Result panel appears after equals.

### Tip
- Three Loan-sized cards in order: Bill Amount, Tip Rate(%), Number of Person.
- Four result rows: Per Person Amount, Total Tip, Per Person Tip, Total Bill Amount.
- Result panel appears after equals; invalid or fractional person count is rejected by the existing calculator logic.

### Percentage
- Reference view contains only Original Amount and Percentage(%).
- Alternate Percent Change panel/tabs/select are hidden; sample values were removed so both fields start empty.
- Result appears after equals. Empty required fields return a validation message, not zero.

### Discount / Salary / SIP
- Editable inputs use the same icon-left, label-above-value card system.
- Discount's hidden compatibility tax input is preserved; visible result rows are shown after equals.
- Salary and SIP result panels appear after equals.

## Shared keypad state machine
1. Tap an editable field: open keypad, mark active field, hide stale result.
2. Enter digits / decimal / AC / delete: update only the active field and recalculate internal preview state.
3. Tap equals: commit result state, persist inputs, close keypad, show result panel.
4. Tap another editable field: clear committed-result visibility and reopen keypad.
5. Navigation action: dismiss keypad before switching screens.

## Known limits
These dimensions are measured estimates from supplied screen captures, not source design tokens from the original third-party app. Device pixel ratio, Android status/navigation bars, display scaling and ad placement can change physical pixel positions. A final screenshot comparison on the user's target phone is still required.
