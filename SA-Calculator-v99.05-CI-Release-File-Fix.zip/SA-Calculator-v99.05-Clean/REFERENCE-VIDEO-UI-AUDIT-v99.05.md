# SA Calculator v99.05 — Reference-video and Android viewport audit

## Release scope
This release carries forward the v99.04 reference-video parity work and adds the v99.05 Android WebView viewport and Tools-navigation corrections. The detailed tool-by-tool observations and calculations remain documented in `REFERENCE-VIDEO-UI-AUDIT-v99.04.md`; this file records the release-specific audit identity and the additional v99.05 checks.

## Inherited reference-video parity
- Preserves the exact 12 requested tools: GST/VAT, Loan, Saving, Salary, Tip, SIP, Currency, Discount, Percentage, Unit, Age, and BMI.
- Preserves the shared keypad and reference-video field layouts, calculator actions, tool-specific controls, and existing calculation engines.
- Retains the detailed screen-by-screen audit, including the limitations where the recording did not expose complete Age/BMI screens or the Saving Goal result formula.
- Historical detailed audit: `REFERENCE-VIDEO-UI-AUDIT-v99.04.md`.

## v99.05 Android screenshot issue and root cause
- A bare `Base application styles.` text node was placed inside the HTML `<head>`. The browser relocated it into the document body.
- The body is a flex container, so this unexpected text became an extra flex item and displaced the application shell horizontally.
- This explains the supplied screenshot symptoms: the left-side text fragment, clipped expression display, clipped right keypad/operator column, and shifted bottom navigation.
- The primary bottom navigation markup contained Calculator, History, and Settings, while the existing application routing and CSS already supported a Tools destination. The missing Tools button meant the user had no visible bottom-navigation route to the 12 tool cards.

## v99.05 corrections
- Removed the stray head text node.
- Hardened the app shell and viewport sizing against horizontal displacement and flex overflow.
- Added a visible Tools bottom-navigation destination wired to the existing Tools screen route.
- Preserved the 12 tool launchers and existing calculator/tool systems.
- Updated release identity to `1.99.19-v99.05`, Android versionCode `1099134`, and service-worker cache namespace `sa-calculator-v99-05-viewport-tools-navigation-v9905`.

## CI and release-entry-point audit
- The v99.05 workflow previously required `REFERENCE-VIDEO-UI-AUDIT-v99.05.md`, but the ZIP contained only the v99.04 audit. This mismatch caused the reported GitHub Actions failure at “Verify source files, release identity and test entry points”.
- Added this correctly versioned v99.05 audit file to the release archive.
- Added `tests/viewport-tools-navigation-v9905.test.mjs` to the CI required-file list so the viewport and Tools-navigation regression test is checked before the test suite runs.
- The standalone Android workflow must remain byte-identical to `.github/workflows/main.yml`.

## Verification boundary
- Automated source-level and regression checks are run for this package.
- A successful local check does not claim that GitHub Actions has completed or that a physical Android device has been tested. The actual workflow run remains the final CI confirmation.
